package crossbrowsertest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;
import pageobjects.CoursesOfferedPage;
import pageobjects.LogInPage;
import pageobjects.Modal;
import pageobjects.ModalLogout;
import pageobjects.WelcomePage;

public class TestSampleCrossBrowser {

	Modal trngModal;
	LogInPage loginPage;
	WelcomePage welcomePage;
	CoursesOfferedPage courses;
	ModalLogout logOutModal;
	
	WebDriver driver;
	ATUTestRecorder recorder;
	String expected = null;
	String actual = null;
	String courseTitle = null;
	String beforeEdit = null;
	private static Logger Log = Logger.getLogger(TestSampleCrossBrowser.class.getName());

	String nodeURL;
	String baseURL;
	
	@BeforeTest
	public void launchBrowser() throws ATUTestRecorderException, IOException {
		// PropertyConfigurator.configure("C:\\Users\\cpi\\Desktop\\Selenium\\Selenium
		// Udemy Workspace\\TrainingPortalSelenium\\log4j.properties");
		
		DOMConfigurator.configure("log4j.xml");

		DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		Date date = new Date();
		// Created object of ATUTestRecorder
		// Provide path to store videos and file name format.
		recorder = new ATUTestRecorder("D:\\ScriptVideos\\", "TestVideo-" + dateFormat.format(date), false);
		// To start video recording.
		recorder.start();

		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability(FirefoxDriver.BINARY, new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe").getAbsolutePath());
		
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\cpi\\Desktop\\Selenium\\Selenium Udemy Workspace\\TrainingPortalSelenium\\src\\crossbrowsertest\\datadriven.properties");
		prop.load(fis);

		driver = new RemoteWebDriver(new URL("http://192.10.10.149:5566/wd/hub"), capabilities);
		/*if (prop.getProperty("browser").contains("chrome")) {
			System.setProperty("webdriver.chrome.driver", prop.getProperty("driverPath"));
			driver = new ChromeDriver();
		} else if (prop.getProperty("browser").contains("IE")) {
			System.setProperty("webdriver.ie.driver", prop.getProperty("driverPath")); // "C:\\Users\\cpi\\Desktop\\Selenium\\Selenium
																						// WebDriver\\Installers\\IEDriverServer_Win32_2.53.1\\IEDriverServer.exe"
																						// );
			driver = new InternetExplorerDriver();
		} else if (prop.getProperty("browser").contains("firefox")) {
			System.setProperty("webdriver.gecko.driver", prop.getProperty("driverPath")); // "C:\\Users\\cpi\\Desktop\\Selenium\\Selenium
																							// WebDriver\\Installers\\geckodriver-v0.10.0-win64"
																							// );
			driver = new FirefoxDriver();
		}
*/
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		Log.info("Opening browser...");
		driver.get(prop.getProperty("url"));
		System.out.println(driver.getTitle());
		trngModal = new Modal(driver);
		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "C:\\Users\\cpi\\Desktop\\Selenium\\Selenium WebDriver\\Installers\\chromedriver_win32\\chromedriver.exe"
		 * ); driver = new ChromeDriver();
		 * 
		 * driver.manage().window().maximize();
		 * driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 * 
		 * Log.info("Opening browser...");
		 * driver.get("http://192.10.10.55:8080/TrainingPortal/");
		 */
	}

	public static void isElementPresent(WebDriver driver, By by, String elementToTest) {

		String isPresent = elementToTest + ": " + driver.findElement(by).isDisplayed();

		Log.info(isPresent);

	}

	@Test(priority = 0)
	public void verifyHomepageTitle() {
		expected = "Training Portal";
		actual = driver.getTitle();
		Log.info("Page Title: " + actual);
		Assert.assertEquals(actual, expected);
		
		Log.info("---------------------------------------------------------");
		
		Log.info("Testing if elements are present in Home Page");
		isElementPresent(driver, By.xpath(".//*[@id='homePage']/img"), "CPI Logo");
		isElementPresent(driver, By.id("inputUser"), "username");
		isElementPresent(driver, By.id("inputPass"), "password");
		isElementPresent(driver, By.id("btnForgotPassword"), "forgot password");
		isElementPresent(driver, By.id("btnLoginID"), "Log In Button");
		isElementPresent(driver, By.id("btnSignUpID"), "Sign Up Button");
		
		Log.info("---------------------------------------------------------");
	}

	@Test(priority = 1)
	@Parameters({ "username", "password" })
	public void LogInTest(String username, String password) throws InterruptedException {
		
		loginPage = new LogInPage(driver);
		
		Log.info("TESTING LOG IN");
		//driver.findElement(By.id("inputUser")).sendKeys(username);
		loginPage.username().sendKeys(username);
		Log.info("Inputted username");
		//driver.findElement(By.id("inputPass")).sendKeys(password);
		loginPage.password().sendKeys(password);
		Log.info("Inputted password");
		Log.info("Logging in...");
		Thread.sleep(1000);
		loginPage.logIn().click();
		Log.info("Log in button clicked");
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		if (driver.findElement(By.linkText("Home")).getAttribute("class").contains("selectedTab")){
			Log.info("Successfully Logged in");
		} else {
			Log.info("Please check your credentials.");
		}
		
	}
	
	@Test(priority = 2)
	public void LogInPageTest() {
		
		Log.info("---------------------------------------------------------");
		
		Log.info("Testing if elements are present in Log In Page");
		isElementPresent(driver, By.xpath(".//*[@id='homePage']/img"), "CPI Logo");
		isElementPresent(driver, By.linkText("Home"), "Home link");
		isElementPresent(driver, By.linkText("Courses Offered"), "Courses Offered link");
		isElementPresent(driver, By.linkText("Enrollment"), "Enrollment link");
		isElementPresent(driver, By.linkText("Training Schedules"), "Training Schedules link");
		isElementPresent(driver, By.id("btnMyAccount"), "My Account Button");
		isElementPresent(driver, By.id("btnLogout"), "Log out Button");
		
		Log.info("---------------------------------------------------------");
		
	}
	
	@Test(priority = 3)
	public void CoursesOfferedTest() throws InterruptedException {
		welcomePage = new WelcomePage(driver);
		
		Thread.sleep(1000);
		Log.info("TESTING COURSES OFFERED LINK");
		welcomePage.coursesOffered().click();
		if (welcomePage.coursesOffered().getAttribute("class").contains("selectedTab")){
			Log.info("Courses Offered Tab selected");
		} else {
			Log.info("There was an error selecting the Courses Offered tab.");
		}
		
		Log.info("---------------------------------------------------------");
		
		Log.info("Testing Elements in Courses Offered Page");
		isElementPresent(driver, By.id("addCourseBtn"), "Add Course Button");
		
		Log.info("---------------------------------------------------------");
		
	}
	
	@Test(priority = 4/*, enabled = false*/)
	public void AddCourseTest() {
		
		courses = new CoursesOfferedPage(driver);
		
		Log.info("TESTING ADDING A COURSE");

		Log.info("Clicking Add Course button..");
		courses.addCourse().click();
		Log.info("Add Course Button clicked");
		String expected = "Add Course:";
		String actual = courses.modifyHeader().getText();
		
		Log.info("Comparing the expected header title with the actual header title..");
		Assert.assertEquals(expected, actual);
		Log.info("Passed");
		
		Log.info("---------------------------------------------------------");
		
		Log.info("Testing Elements in Add Courses Page");
		isElementPresent(driver, By.xpath(".//*[@id='back']/span"), "Back Glyphicon Button");
		isElementPresent(driver, By.id("title"), "Course Name");
		isElementPresent(driver, By.id("description"), "Description");
		isElementPresent(driver, By.xpath(".//*[@id='descriptionDiv']/span"), "Description Overlay");
		isElementPresent(driver, By.id("objectives"), "Objectives");
		isElementPresent(driver, By.xpath(".//*[@id='objectivesDiv']/span"), "Objectives Overlay");
		isElementPresent(driver, By.id("prerequisites"), "Pre-requisites");
		isElementPresent(driver, By.id("duration"), "Duration");
		isElementPresent(driver, By.id("outline"), "Outline");
		isElementPresent(driver, By.xpath(".//*[@id='outlineDiv']/span"), "Outline Overlay");
		isElementPresent(driver, By.xpath(".//input[@value='Save']"), "Save Button");
		isElementPresent(driver, By.id("btnCourseCancel"), "Cancel Button");
		
		Log.info("---------------------------------------------------------");
		
		Log.info("Testing one liner inputs");
		courses.courseName().sendKeys("sample title");
		Log.info("Inputted title");
		courses.courseDescription().sendKeys("sample description");
		Log.info("Inputted description");
		courses.courseObjectives().sendKeys("sample objectives");
		Log.info("Inputted objectives");
		courses.coursePrerequisites().sendKeys("sample prerequisites");
		Log.info("Inputted prerequisites");
		courses.courseDuration().sendKeys("sample duration");
		Log.info("Inputted duration");
		courses.courseOutline().sendKeys("sample outline");
		Log.info("Inputted outline");
		courses.saveCourse().click();
		Log.info("Save Button clicked");
		
		new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='myModal']/div/div/div[3]")));
		Log.info(trngModal.modalMessage().getText());
		trngModal.btnModalOk().click();
		Log.info("Modal OK Button clicked");
		
		if(courses.courseDtlTab().isDisplayed()){
			Log.info("Back to Courses Offered Page");
		} else {
			Log.info("There was an error refreshing Courses Offered Page");
		}
		
	}
	
	@Test(priority = 5)
	public void EditCourseTest() throws InterruptedException {
		Thread.sleep(1000);
		Log.info("TESTING EDITING A COURSE");
		
		WebElement htmlTable = courses.courseDtlTab();
		
		List<WebElement> rows = htmlTable.findElements(By.tagName("tr"));
		
		for (int i = 0; i<rows.size(); i++){
			if(rows.get(i).getText().contains("sample title")){
				courseTitle = rows.get(i).getText().substring(0, "sample title".length());
				Log.info(courseTitle + " column clicked");
				rows.get(i).click();
				break;
			}
		}
	}
	
	@Test(priority = 6)//(priority = 4)
	public void TestClickedCourse() throws InterruptedException {
		
		Log.info("---------------------------------------------------------");
		
		Log.info("Testing elements in Clicked Table Data Page");
		
		isElementPresent(driver, By.xpath(".//*[@id='back']/span"), "Back Glyphicon Button");
		isElementPresent(driver, By.id("titleHead"), "Title Head / Course Name");
		isElementPresent(driver, By.id("btnUpload"), "Upload Button");
		isElementPresent(driver, By.id("updateDtl"), "Update Button");
		isElementPresent(driver, By.id("deleteDtl"), "Delete Button");
		isElementPresent(driver, By.id("description"), "Description");
		isElementPresent(driver, By.id("objective"), "Objectives");
		isElementPresent(driver, By.id("prerequisite"), "Pre-requisites");
		isElementPresent(driver, By.id("duration"), "Duration");
		isElementPresent(driver, By.id("outline"), "Outline");
		
		Log.info("---------------------------------------------------------");
		
		beforeEdit = courses.courseDescription().getText(); // for checking if this was edited
		Log.info("Before edit: " + beforeEdit);
		String titleHead = courses.titleHead().getText();
		
		Log.info("Comparing the expected course title with the actual title head..");
		Assert.assertEquals(courseTitle, titleHead);
		Log.info("Passed");
		
		/*if (courseTitle.equalsIgnoreCase(titleHead)){
			Log.info("PASSED");
		} else {
			Log.info("FAILED: Wrong Title Head.");
		}*/
		
	}
	
	@Test(priority = 7)
	public void editCourse() throws InterruptedException{
		Thread.sleep(1000);
		courses.updateCourse().click();
		Log.info("Update button clicked");
		
		Log.info("---------------------------------------------------------");
		
		Log.info("Testing elements in Clicked Table Data Page");
		
		//isElementPresent(driver, By.id("modifyHeader"), "Edit Course");
		isElementPresent(driver, By.id("title"), "Course Name");
		isElementPresent(driver, By.id("description"), "Description");
		isElementPresent(driver, By.xpath(".//*[@id='descriptionDiv']/span"), "Description Overlay");
		isElementPresent(driver, By.id("objectives"), "Objectives");
		isElementPresent(driver, By.xpath(".//*[@id='objectivesDiv']/span"), "Objectives Overlay");
		isElementPresent(driver, By.id("prerequisites"), "Pre-requisites");
		isElementPresent(driver, By.id("duration"), "Duration");
		isElementPresent(driver, By.id("outline"), "Outline");
		isElementPresent(driver, By.xpath(".//*[@id='outlineDiv']/span"), "Outline Overlay");
		isElementPresent(driver, By.xpath(".//input[@value='Save']"), "Save Button");
		isElementPresent(driver, By.id("btnCourseCancel"), "Cancel Button");
		
		Log.info("---------------------------------------------------------");
		
		String expected = "Edit Course:";
		String actual = courses.modifyHeader().getText();
		
		Log.info("Comparing the expected header title with the actual header title..");
		Assert.assertEquals(expected, actual);
		Log.info("Passed");
		
		courses.editDescPopup().click();
		//driver.findElement(By.id("description")).clear();
		new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='myModal']/div/div/div[2]")));
		Log.info(trngModal.modalTitle().getText());
		Thread.sleep(1000);
		String edited = trngModal.poupEditText().getText() + " sample edit"; 
		trngModal.poupEditText().sendKeys(" sample edit");
		trngModal.editPopupCourseBtnOk().click();
		Thread.sleep(1000);
		Log.info("Inputted text: " + edited);
		
		Thread.sleep(1000);
		courses.saveCourse().click();
		Thread.sleep(1000);
		Log.info("Save button clicked");
		

		//new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='myModal']/div/div/div[2]")));
		//Log.info(trngModal.modal().getText());
		//Thread.sleep(1000);
		//trngModal.btnModalOk().click();
		//Thread.sleep(1000);
		//Log.info("Modal OK Button clicked");
		
		String afterEdit = courses.courseDescription().getText();
		Log.info("After editing: " + afterEdit);
		
		Log.info("Comparing the description before editing and after editing..");
		Assert.assertNotEquals(beforeEdit, afterEdit);
		Log.info("Passed");
		
		Log.info(edited);
		Log.info(afterEdit);
		Log.info("Comparing the edited description with the inputted description..");
		Assert.assertEquals(edited, afterEdit);
		Log.info("Passed");
	}
	
	@Test(priority = 8)
	public void deleteCourse() throws InterruptedException{
		Log.info("TESTING DELETING A COURSE");
		Thread.sleep(1000);
		courses.deleteCourse().click();
		Log.info("Delete button clicked");
		
		new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='myModal']/div/div/div[3]")));
		Log.info(trngModal.modal().getText());
		Thread.sleep(1000);
		trngModal.btnModalDelete().click();
		Thread.sleep(1000);
		Log.info("Modal Delete Button clicked");
		
		new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='myModal']/div/div/div[3]")));
		Log.info(trngModal.modal().getText());
		Thread.sleep(1000);
		trngModal.btnModalOk().click();
		Thread.sleep(1000);
		Log.info("Modal Ok Button clicked");
		
		if (!courses.courseDtlTab().getText().contains("sample title")){
			Log.info("Passed");
		} else {
			Log.info("Failed deleting course");
		}
	}
	
	@Test(priority = 9)
	public void testLogOut() throws InterruptedException {
		logOutModal = new ModalLogout(driver);
		
		Log.info("TESTING LOGGING OUT");
		Thread.sleep(1000);
		Log.info("Logging out...");
		welcomePage.logOut().click();
		
		new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='modalLogOut']/div/div/div[3]")));
		Log.info(logOutModal.modalLogoutMessage().getText());
		Thread.sleep(1000);
		logOutModal.btnLogOutYes().click();
		Log.info("Clicked Yes");
		Thread.sleep(1000);
		Log.info("Logged out");
		
	}
	
	
	@AfterTest
	public void terminateBrowser() throws ATUTestRecorderException, InterruptedException{
		Log.info("Closing browser...");
		Thread.sleep(1000);
		driver.quit();
		Log.info("Browser closed");
		 //To stop video recording.
		recorder.stop();
	}
	
}
