package exceldriven;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDrivenTest {

	public static XSSFWorkbook wb; 
	public static XSSFSheet sheet;
	public static XSSFRow row;
	public static XSSFCell cell;
	public static FileInputStream fis;
	
	public static void main(String[] args) throws IOException {

		String value = getCellData(2,2);
		System.out.println(value);
		String value2 = getCellData(1,2);
		System.out.println(value2);
		
		String value3 = setCellData("hayyyyy", 1, 2);
		System.out.println(value3);
		String value4 = setCellData("haaaaaaaaaay", 2, 2);
		System.out.println(value4);
		
	}
	
	public static String getCellData(int rownum, int colnum) throws IOException{
		
		fis = new FileInputStream("C:\\Users\\cpi\\Desktop\\Selenium\\Selenium Udemy Workspace\\data.xlsx");
		wb = new XSSFWorkbook(fis);
		sheet = wb.getSheet("script");
		row = sheet.getRow(rownum);
		cell = row.getCell(colnum);
		
		return cell.getStringCellValue();
		
	}
	
	public static String setCellData(String text, int rownum, int colnum) throws IOException{
		
		fis = new FileInputStream("C:\\Users\\cpi\\Desktop\\Selenium\\Selenium Udemy Workspace\\data.xlsx");
		wb = new XSSFWorkbook(fis);
		sheet = wb.getSheet("script");
		row = sheet.getRow(rownum);
		cell = row.getCell(colnum);
		cell.setCellValue(text);
		
		
		String cellValue = cell.getStringCellValue();
		return cellValue;
		
	}

}

