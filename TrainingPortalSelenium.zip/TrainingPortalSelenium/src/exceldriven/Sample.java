package exceldriven;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Sample {

	
	@Test
	public void open() throws InterruptedException{
		
		System.setProperty("webdriver.firefox.marionette","C:\\Users\\cpi\\Desktop\\Selenium\\Selenium WebDriver\\Installers\\geckodriver-v0.10.0-win64");
		
		WebDriver driver=new FirefoxDriver();
		/*System.setProperty("webdriver.chrome.driver", "C:\\Users\\cpi\\Desktop\\Selenium\\Selenium WebDriver\\Installers\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();*/
		driver.get("http://192.10.10.55:8080/TrainingPortal");
		driver.findElement(By.id("inputUser")).sendKeys("admin");
		driver.findElement(By.id("inputPass")).sendKeys("password");
		driver.findElement(By.id("btnLoginID")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Training Schedules")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("addBtn")).click();
		Select dropdown = new Select(driver.findElement(By.id("trngNm")));
		dropdown.selectByIndex(4);	
		System.out.println(driver.findElement(By.id("trngNm")).getText());
		System.out.println(dropdown.getFirstSelectedOption());
		
		
		driver.findElement(By.id("trngStrtDate1")).click();
					
		List<WebElement> dates=driver.findElements(By.xpath(".//*[@id='mainPageBody']/div[4]/div[1]/table/tbody/tr/td"));
		
		
		for(WebElement sd:dates)
		{
			
			String startDate=sd.getText();
			
			if(startDate.equalsIgnoreCase("24"))
			{
				sd.click();
				break;
			}
			
		}
		
		
		driver.findElement(By.id("trngEndDate1")).click();
		//new WebDriverWait(driver, 10).until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath(".//*[@id='mainPageBody']/div[4]/div[1]/table/tbody/tr/td"))));
		//new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='mainPageBody']/div[4]/div[1]/table/tbody/tr/td")));
		new WebDriverWait(driver, 10).until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='mainPageBody']/div[4]/div[1]/table/tbody/tr/td")));
		    driver.findElement(By.xpath(".//*[@id='mainPageBody']/div[4]/div[1]/table/tbody/tr/td")).click();
		//System.out.println(driver.findElement(By.xpath(".//*[@id='mainPageBody']/div[4]/div[1]/table/tbody/tr/td")).isDisplayed());
		
		for(WebElement ed:dates)
		{
			
			String endDates=ed.getText();
			
			if(endDates.equalsIgnoreCase("27"))
			{
				ed.click();
				break;
			}
			
		}
		
		
		
		/*List<WebElement> endDates=driver.findElements(By.xpath(".//*[@id='mainPageBody']/div[4]/div[1]/table/tbody/tr/td"));
		
		for(WebElement ed:endDates)
		{
			
			String endDate=ed.getText();
			
			if(endDate.equalsIgnoreCase("27"))
			{
				ed.click();
				break;
			}
			
		}*/
		
		//driver.findElement(By.id("currCode")).click();
		
		Select currCode = new Select(driver.findElement(By.id("currCode")));
		currCode.selectByIndex(4);
		
		
		Select trngStat = new Select(driver.findElement(By.id("trngStat")));
		trngStat.selectByIndex(2);
		
	}

	private WebElement findElement(By xpath) {
		// TODO Auto-generated method stub
		return null;
	}
 
}
	