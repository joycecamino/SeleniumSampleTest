package exceldriven;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sample2 {

	public static XSSFWorkbook wb; 
	public static XSSFSheet sheet;
	public static XSSFRow row;
	public static XSSFCell cell;
	public static FileInputStream fis;
	
	public static void main(String[] args) throws IOException {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cpi\\Desktop\\Selenium\\Selenium WebDriver\\Installers\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://192.10.10.55:8080/TrainingPortal");
		
		/*Workbook workbook; //<-Interface, accepts both HSSF and XSSF.
		File file = new File("YourExcelFile.xlsx");
		if (FileUtils.getFileExt(file).equalsIgnoreCase("xls")) {
		  workbook = new HSSFWorkbook(new FileInputStream(file));
		} else if (FileUtils.getFileExt(file).equalsIgnoreCase("xlsx")) {
		  workbook = new XSSFWorkbook(new FileInputStream(file));
		} else {
		  throw new IllegalArgumentException("Received file does not have a standard excel extension.");
		}*/
		
		
		
		//username
		String id1 = getCellData(1,0);
		String action1 = getCellData(1,1);
		String input1 = getCellData(1,2);
		
		System.out.println(id1);
		driver.findElement(By.id(id1)).sendKeys(input1);
		
		//password
		String id2 = getCellData(2,0);
		String action2 = getCellData(2,1);
		String input2 = getCellData(2,2);
		
		System.out.println(id2);
		driver.findElement(By.id(id2)).sendKeys(input2);
		
		//login button
		String id3 = getCellData(3,0);
		String action3 = getCellData(3,1);
		String input3 = getCellData(3,2);
		
		System.out.println(id3);
		driver.findElement(By.id(id3)).click();
		
		
		/*String value = getCellData(2,2);
		System.out.println(value);
		String value2 = getCellData(1,2);
		System.out.println(value2);
		
		String value3 = setCellData("hayyyyy", 1, 2);
		System.out.println(value3);
		String value4 = setCellData("haaaaaaaaaay", 2, 2);
		System.out.println(value4);*/
		
	}
	
	public static String getCellData(int rownum, int colnum) throws IOException{
		
		fis = new FileInputStream("C:\\Users\\cpi\\Desktop\\Selenium\\Selenium Udemy Workspace\\sample.xlsx");
		wb = new XSSFWorkbook(fis);
		sheet = wb.getSheet("sheet1");
		row = sheet.getRow(rownum);
		cell = row.getCell(colnum);
		
		return cell.getStringCellValue();
		
	}
	
	public static String setCellData(String text, int rownum, int colnum) throws IOException{
		
		fis = new FileInputStream("C:\\Users\\cpi\\Desktop\\Selenium\\Selenium Udemy Workspace\\sample.xlsx");
		wb = new XSSFWorkbook(fis);
		sheet = wb.getSheet("sheet1");
		row = sheet.getRow(rownum);
		cell = row.getCell(colnum);
		cell.setCellValue(text);
		
		
		String cellValue = cell.getStringCellValue();
		return cellValue;
		
	}

}

