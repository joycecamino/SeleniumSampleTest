package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignUpPage {

	WebDriver driver;
	
	@FindBy(id="regContent")
	WebElement signUpModal;

	@FindBy(id="compSelect1")
	WebElement selCompName;
	
	@FindBy(id="inputCompName")
	WebElement inputCompName;

	@FindBy(id="inputAddress")
	WebElement inputAddress;

	@FindBy(id="inputEmail")
	WebElement compEmail;

	@FindBy(id="inputPhone")
	WebElement compPhone;

	@FindBy(id="inputContact")
	WebElement inputContact;

	@FindBy(id="selectAccountType")
	WebElement selAccountType;
	
	@FindBy(id="inputFirstName")
	WebElement firstName;
	
	@FindBy(id="inputMiddleInitial")
	WebElement middleInitial;
	
	@FindBy(id="inputLastName")
	WebElement lastName;
	
	@FindBy(id="inputUserEmail")
	WebElement userEmail;
	
	@FindBy(id="inputUsername1")
	WebElement usernameSignUp;
	
	@FindBy(id="inputPassword1")
	WebElement passwordSignUp;
	
	@FindBy(id="inputConfirmPassword")
	WebElement passwordConfirm;
	
	@FindBy(id="btnSignUpID2")
	WebElement signUpBtn;
	
	@FindBy(id="btnClose")
	WebElement signUpCloseBtn;
	
	@FindBy(id="btnModalCLose")
	WebElement signUpModalCLose;
	
	/*@FindBy(id="")
	WebElement ;

	@FindBy(id="")
	WebElement ;

	@FindBy(id="")
	WebElement ;*/

	public SignUpPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getSignUpModal(){
		return signUpModal;
	}
	
	public WebElement selectCompName(){
		return selCompName;
	}
	
	public WebElement typeCompName(){
		return inputCompName;
	}
	
	public WebElement companyAddress(){
		return inputAddress;
	}
	
	public WebElement companyEmail(){
		return compEmail;
	}
	
	public WebElement compPhone(){
		return compPhone;
	}
	
	public WebElement contactPerson(){
		return inputContact;
	}
	
	public WebElement selectAcctType(){
		return selAccountType;
	}
	
	public WebElement inputFirstName(){
		return firstName;
	}
	
	public WebElement inputMiddleInitial(){
		return middleInitial;
	}
	
	public WebElement inputLastName(){
		return lastName;
	}
	
	public WebElement userEmailAddress(){
		return userEmail;
	}
	
	public WebElement userSignUp(){
		return usernameSignUp;
	}
	
	public WebElement passSignUp(){
		return passwordSignUp;
	}
	
	public WebElement passConfirm(){
		return passwordConfirm;
	}
	
	public WebElement signUp(){
		return signUpBtn;
	}
	
	public WebElement closeSignUp(){
		return signUpCloseBtn;
	}
	
	public WebElement closeSignUpModal(){
		return signUpModalCLose;
	}
	
}
