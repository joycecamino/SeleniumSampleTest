package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UploadForm {

WebDriver driver;
	
	@FindBy(xpath=".//*[@id='uploadFile']/div")
	WebElement modalUploadFile;	
	
	@FindBy(id="myModalLabel")
	WebElement uploadFileLabel;
	
	@FindBy(xpath=".//*[@id='upload-form']/div/div[2]/div/div/div[1]/label[1]")
	WebElement teacherRadioBtn;
	
	@FindBy(xpath=".//*[@id='upload-form']/div/div[2]/div/div/div[1]/label[2]")
	WebElement studentRadioBtn;
	
	@FindBy(xpath=".//*[@id='upload-form']/div/div[2]/div/div/div[1]/label[3]")
	WebElement teacherStudentRadioBtn;

	@FindBy(id="fileUpload")
	WebElement browseFile;
	
	@FindBy(id="btnSave")
	WebElement btnSaveUpload;
	
	@FindBy(id="btnClose")
	WebElement btnCloseFileUpload;
	
	@FindBy(xpath=".//*[@id='upload-form']/div/a")
	WebElement downloadAll;
	
	@FindBy(xpath=".//*[@id='upload-form']/div/div[1]/table/tbody/tr/td[2]/a")
	WebElement downloadFile;
	
	@FindBy(xpath=".//*[@id='upload-form']/div/div[1]/table/tbody/tr/td[2]/button")
	WebElement deleteFile;
	
	@FindBy(xpath=".//*[@id='upload-form']/div/div[1]/table/tbody")
	WebElement filesUploadedTab;
	
	@FindBy(id="allFiles")
	WebElement allFiles;
	
	
	public UploadForm(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement modalUploadFile(){
		return modalUploadFile;
	}
	
	public WebElement uploadFileLabel(){
		return uploadFileLabel;
	}
	
	public WebElement teacherRadioBtn(){
		return teacherRadioBtn;
	}
	
	public WebElement studentRadioBtn(){
		return studentRadioBtn;
	}
	
	public WebElement teacherStudentRadioBtn(){
		return teacherStudentRadioBtn;
	}
	
	public WebElement browseFile(){
		return browseFile;
	}
	
	
	public WebElement btnSaveUpload(){
		return btnSaveUpload;
	}
		
			
	public WebElement btnCloseFileUpload(){
		return btnCloseFileUpload;
	}
	
	public WebElement downloadAll(){
		return downloadAll;
	}
	
	public WebElement downloadFile(){
		return downloadFile;
	}
	
	public WebElement deleteFile(){
		return deleteFile;
	}
	
	public WebElement filesUploadedTab(){
		return filesUploadedTab;
	}
	
	public WebElement allFiles(){
		return allFiles;
	}
	
	
}
