package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LogInPage {

	WebDriver driver;
	
	@FindBy(id="inputUser")
	WebElement inputUsername;
	
	@FindBy(id="inputPass")
	WebElement inputPassword;
	
	@FindBy(id="btnLoginID")
	WebElement logInBtn;
	
	@FindBy(id="btnSignUpID")
	WebElement signUpBtn;
	
	@FindBy(id="btnForgotPassword")
	WebElement forgotPassBtn;
	
	@FindBy(id="myModal")
	WebElement forgotModal;
	
	@FindBy(id="btnModalOk")
	WebElement forgotModalOKBtn;
	
	public LogInPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement username(){
		return inputUsername;
	}
	
	public WebElement password(){
		return inputPassword;
	}
	
	public WebElement logIn(){
		return logInBtn;
	}
	
	public WebElement signUp(){
		return signUpBtn;
	}
	
	public WebElement forgotPassword(){
		return forgotPassBtn;
	}
	
	public WebElement getForgotModal(){
		return forgotModal;
	}
	
	public WebElement forgotModalOK(){
		return forgotModalOKBtn;
	}
	
	
}
