package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Modal {

	WebDriver driver;
	
	@FindBy(xpath=".//*[@id='myModal']/div")
	WebElement modal;	
	
	@FindBy(id="modalTitle")
	WebElement modalTitle;
	
	@FindBy(id="message")
	WebElement modalMessage;

	@FindBy(id="btnModalDelete")
	WebElement btnModalDelete;
	
	@FindBy(id="btnModalCancel")
	WebElement btnModalCancel;
	
	@FindBy(id="btnModalOk")
	WebElement btnModalOk;
	
	//course popup
	@FindBy(id="newText")
	WebElement poupEditText;
	
	@FindBy(id="btnTextEditorOk")
	WebElement editPopupBtnOk;
	
	
	public Modal(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement modal(){
		return modal;
	}
	
	public WebElement modalTitle(){
		return modalTitle;
	}
	
	public WebElement modalMessage(){
		return modalMessage;
	}
	
	public WebElement btnModalDelete(){
		return btnModalDelete;
	}
	
	public WebElement btnModalCancel(){
		return btnModalCancel;
	}
	
	public WebElement btnModalOk(){
		return btnModalOk;
	}
	
	
	public WebElement poupEditText(){
		return poupEditText;
	}
		
			
	public WebElement editPopupCourseBtnOk(){
		return editPopupBtnOk;
	}
}
