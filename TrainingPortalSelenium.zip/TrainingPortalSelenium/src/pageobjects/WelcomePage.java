package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WelcomePage {
	
	WebDriver driver;
	
	@FindBy(id="lnkMainHome")
	WebElement homeLink;

	@FindBy(id="lnkCourses")
	WebElement coursesLink;
	
	@FindBy(id="lnkEnrollment")
	WebElement inputEnrollmentLink;

	@FindBy(id="lnkTrngSched")
	WebElement trngSchedLink;

	@FindBy(id="btnMyAccount")
	WebElement myAccountBtn;

	@FindBy(id="btnLogout")
	WebElement logOutBtn;

	/*@FindBy(id="inputContact")
	WebElement inputContact;

	@FindBy(id="selectAccountType")
	WebElement selAccountType;
	
	@FindBy(id="inputFirstName")
	WebElement firstName;
	
	@FindBy(id="inputMiddleInitial")
	WebElement middleInitial;
	
	@FindBy(id="inputLastName")
	WebElement lastName;
	
	@FindBy(id="inputUserEmail")
	WebElement userEmail;
	
	@FindBy(id="inputUsername1")
	WebElement usernameSignUp;
	
	@FindBy(id="inputPassword1")
	WebElement passwordSignUp;
	
	@FindBy(id="inputConfirmPassword")
	WebElement passwordConfirm;
	
	@FindBy(id="btnSignUpID2")
	WebElement signUpBtn;
	
	@FindBy(id="btnClose")
	WebElement signUpCloseBtn;
	
	@FindBy(id="btnModalCLose")
	WebElement signUpModalCLose;*/
	
	/*@FindBy(id="")
	WebElement ;

	@FindBy(id="")
	WebElement ;

	@FindBy(id="")
	WebElement ;*/

	public WelcomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement home(){
		return homeLink;
	}
	
	public WebElement coursesOffered(){
		return coursesLink;
	}
	
	public WebElement enrollment(){
		return inputEnrollmentLink;
	}
	
	public WebElement trngSched(){
		return trngSchedLink;
	}
	
	public WebElement myAccount(){
		return myAccountBtn;
	}
	
	public WebElement logOut(){
		return logOutBtn;
	}
	
	/*public WebElement contactPerson(){
		return inputContact;
	}
	
	public WebElement selectAcctType(){
		return selAccountType;
	}
	
	public WebElement inputFirstName(){
		return firstName;
	}
	
	public WebElement inputMiddleInitial(){
		return middleInitial;
	}
	
	public WebElement inputLastName(){
		return lastName;
	}
	
	public WebElement userEmailAddress(){
		return userEmail;
	}
	
	public WebElement userSignUp(){
		return usernameSignUp;
	}
	
	public WebElement passSignUp(){
		return passwordSignUp;
	}
	
	public WebElement passConfirm(){
		return passwordConfirm;
	}
	
	public WebElement signUp(){
		return signUpBtn;
	}
	
	public WebElement closeSignUp(){
		return signUpCloseBtn;
	}
	
	public WebElement closeSignUpModal(){
		return signUpModalCLose;
	}*/
	
}
