package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ModalLogout {

WebDriver driver;
	
	@FindBy(id="modalLogOut")
	WebElement modalLogout;	
	
	@FindBy(xpath=".//*[@id='modalLogOut']/div/div/div[1]/h4")
	WebElement modalLogoutTitle;
	
	@FindBy(xpath=".//*[@id='modalLogOut']/div/div/div[2]/div")
	WebElement modalLogoutMessage;

	@FindBy(id="btnLogOutYes")
	WebElement btnLogOutYes;
	
	@FindBy(id="btnLogOutNo")
	WebElement btnLogOutNo;
	
	
	public ModalLogout(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement modalLogout(){
		return modalLogout;
	}
	
	public WebElement modalLogoutTitle(){
		return modalLogoutTitle;
	}
	
	public WebElement modalLogoutMessage(){
		return modalLogoutMessage;
	}
	
	public WebElement btnLogOutYes(){
		return btnLogOutYes;
	}
	
	public WebElement btnLogOutNo(){
		return btnLogOutNo;
	}
	
}
