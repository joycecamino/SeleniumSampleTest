package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CoursesOfferedPage {
	
	WebDriver driver;
	
	@FindBy(id="addCourseBtn")
	WebElement addCourseBtn;

	@FindBy(xpath=".//*[@id='content']/div[2]/div/table/tbody")
	WebElement tableContent;
	
	@FindBy(id="back")
	WebElement backCourseGlyph;
	
	@FindBy(id="modifyHeader")
	WebElement modifyHeader;

	@FindBy(id="btnUpload")
	WebElement uploadFile;

	@FindBy(id="updateDtl")
	WebElement updateCourse;

	@FindBy(id="deleteDtl")
	WebElement deleteCourse;

	@FindBy(id="titleHead")
	WebElement titleHead;
	
	@FindBy(id="title")
	WebElement courseName;
	
	@FindBy(id="duration")
	WebElement duration;

	@FindBy(id="prerequisites")
	WebElement prerequisites;
	
	@FindBy(id="description")
	WebElement description;
	
	@FindBy(id="objectives")
	WebElement objectives;
	
	@FindBy(id="outline")
	WebElement outline;
	
	@FindBy(xpath="//input[@value='Save']")
	WebElement saveCourse;
	
	@FindBy(id="btnCourseCancel")
	WebElement courseCancel;
	
	@FindBy(xpath=".//*[@id='descriptionDiv']/span")
	WebElement editDescGlyph;
	
	@FindBy(xpath=".//*[@id='objectivesDiv']/span")
	WebElement editObjectivesGlyph;
	
	@FindBy(xpath=".//*[@id='outlineDiv']/span")
	WebElement editOutlineGlyph;
	
	/*@FindBy(id="newText")
	WebElement poupEditText;
	
	@FindBy(id="btnTextEditorOk")
	WebElement editPopupBtnOk;*/
	
	/*@FindBy(xpath=".//*[@id='myModal']/div/div/div[2]")
	WebElement popupCourseModal;*/
	
	/*@FindBy(id="btnTextEditorOk")
	WebElement editPopupBtnOk;
	
	@FindBy(id="btnModalCancel")
	WebElement editPopupCancel;*/
	
	/*@FindBy(id="")
	WebElement ;*/
	

	public CoursesOfferedPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement addCourse(){
		return addCourseBtn;
	}
	
	public WebElement courseDtlTab(){
		return tableContent;
	}
	
	public WebElement backCourseGlyph(){
		return backCourseGlyph;
	}
	
	public WebElement modifyHeader(){
		return modifyHeader;
	}
	
	public WebElement courseUploadFile(){
		return uploadFile;
	}
	
	public WebElement updateCourse(){
		return updateCourse;
	}
	
	public WebElement deleteCourse(){
		return deleteCourse;
	}
	
	public WebElement titleHead(){
		return titleHead;
	}
	
	public WebElement courseName(){
		return courseName;
	}
	
	public WebElement courseDuration(){
		return duration;
	}
	
	public WebElement coursePrerequisites(){
		return prerequisites;
	}
	
	public WebElement courseDescription(){
		return description;
	}
	
	public WebElement courseObjectives(){
		return objectives;
	}
	
	public WebElement courseOutline(){
		return outline;
	}
	
	public WebElement saveCourse(){
		return saveCourse;
	}
	
	public WebElement courseCancel(){
		return courseCancel;
	}
	
	public WebElement editDescPopup(){
		return editDescGlyph;
	}
	
	public WebElement editObjectivesPopup(){
		return editObjectivesGlyph;
	}
	
	public WebElement editOutlinePopup(){
		return editOutlineGlyph;
	}
	
	/*public WebElement poupEditText(){
		return poupEditText;
	}
		
			
	public WebElement editPopupBtnOk(){
		return editPopupBtnOk;
	}
		
	public WebElement editPopupCancel(){
		return editPopupCancel;
	}*/
	/*public WebElement (){
		return ;
	}*/
	
}
